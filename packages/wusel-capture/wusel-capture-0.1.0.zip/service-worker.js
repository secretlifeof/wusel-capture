// src/lib/id.ts
function makeId(prefix = "cap") {
  return `${prefix}_${crypto.randomUUID()}`;
}

// src/lib/page-info.ts
function collectPageInfo() {
  const ua = navigator.userAgent;
  const nav = navigator;
  const grab = (re) => {
    const m = ua.match(re);
    return m ? m[1] : "";
  };
  let name = "Unknown";
  let version = "";
  if (/Edg\//.test(ua)) {
    name = "Edge";
    version = grab(/Edg\/([\d.]+)/);
  } else if (/OPR\//.test(ua) || /Opera/.test(ua)) {
    name = "Opera";
    version = grab(/(?:OPR|Opera)\/([\d.]+)/);
  } else if (/Firefox\//.test(ua)) {
    name = "Firefox";
    version = grab(/Firefox\/([\d.]+)/);
  } else if (/Chrome\//.test(ua)) {
    name = nav.brave ? "Brave" : "Chrome";
    version = grab(/Chrome\/([\d.]+)/);
  } else if (/Safari\//.test(ua) && /Version\//.test(ua)) {
    name = "Safari";
    version = grab(/Version\/([\d.]+)/);
  }
  let platform = nav.userAgentData?.platform || navigator.platform || "";
  if (/Windows NT/.test(ua)) platform = "Windows";
  else if (/Mac OS X/.test(ua)) platform = "macOS";
  else if (/Android/.test(ua)) platform = "Android";
  else if (/(iPhone|iPad|iPod)/.test(ua)) platform = "iOS";
  else if (!platform && /Linux/.test(ua)) platform = "Linux";
  const mobile = typeof nav.userAgentData?.mobile === "boolean" ? nav.userAgentData.mobile : /Mobile|Android|iPhone|iPad|iPod/.test(ua);
  return {
    url: location.href,
    title: document.title,
    userAgent: ua,
    viewport: { width: window.innerWidth, height: window.innerHeight },
    devicePixelRatio: window.devicePixelRatio,
    scroll: { x: Math.round(window.scrollX), y: Math.round(window.scrollY) },
    browser: {
      name,
      version,
      platform,
      language: navigator.language || "",
      screen: { width: window.screen?.width ?? 0, height: window.screen?.height ?? 0 },
      mobile,
      touchPoints: navigator.maxTouchPoints || 0
    }
  };
}

// src/lib/redact.ts
var SECRET_KEY = /(token|secret|password|authorization|cookie|session|jwt|api[_-]?key|access)/i;
function redactUrl(rawUrl) {
  try {
    const url = new URL(rawUrl, "http://invalid.local");
    let changed = false;
    for (const key of Array.from(url.searchParams.keys())) {
      if (SECRET_KEY.test(key)) {
        url.searchParams.set(key, "[REDACTED]");
        changed = true;
      }
    }
    if (!changed) return rawUrl;
    return url.origin === "http://invalid.local" ? url.pathname + url.search : url.toString();
  } catch {
    return rawUrl;
  }
}

// src/storage.ts
var DB_NAME = "ck-capture";
var STORE = "captures";
var VERSION = 1;
function openDb() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, VERSION);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(STORE)) db.createObjectStore(STORE, { keyPath: "id" });
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}
function tx(mode, run) {
  return openDb().then(
    (db) => new Promise((resolve, reject) => {
      const transaction = db.transaction(STORE, mode);
      const request = run(transaction.objectStore(STORE));
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
      transaction.oncomplete = () => db.close();
    })
  );
}
function putCapture(payload) {
  return tx("readwrite", (store) => store.put(payload));
}
function pruneCaptures(keepNewest) {
  return openDb().then(
    (db) => new Promise((resolve, reject) => {
      const transaction = db.transaction(STORE, "readwrite");
      const store = transaction.objectStore(STORE);
      const req = store.getAll();
      req.onsuccess = () => {
        const stale = req.result.sort((a, b) => b.capturedAt.localeCompare(a.capturedAt)).slice(keepNewest);
        for (const old of stale) store.delete(old.id);
      };
      transaction.oncomplete = () => {
        db.close();
        resolve();
      };
      transaction.onerror = () => reject(transaction.error);
    })
  );
}

// src/background/service-worker.ts
var MAX_DIMENSION = 16384;
chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (!message || typeof message !== "object" || message.type !== "CAPTURE") {
    return false;
  }
  handleCapture(message).then(() => sendResponse({ ok: true })).catch(
    (err) => sendResponse({ ok: false, error: err instanceof Error ? err.message : String(err) })
  );
  return true;
});
async function handleCapture(req) {
  const { mode, tabId, windowId } = req;
  const info = await getPageInfo(tabId);
  const imageDataUrl = await capture(mode, tabId, windowId);
  const { width, height } = await imageSize(imageDataUrl);
  const payload = {
    id: makeId(),
    capturedAt: (/* @__PURE__ */ new Date()).toISOString(),
    captureMode: mode,
    imageDataUrl,
    imageWidth: width,
    imageHeight: height,
    page: info.page,
    diagnostics: redactDiagnostics(info.diagnostics)
  };
  await putCapture(payload);
  await pruneCaptures(10).catch(() => void 0);
  await chrome.tabs.create({ url: chrome.runtime.getURL(`editor.html?id=${payload.id}`) });
}
function capture(mode, tabId, windowId) {
  if (mode === "viewport") return captureViewport(windowId);
  if (mode === "fullpage") return captureFullPage(tabId);
  return captureRegion(tabId, windowId);
}
function captureViewport(windowId) {
  return chrome.tabs.captureVisibleTab(windowId, { format: "png" });
}
async function captureFullPage(tabId) {
  const target = { tabId };
  try {
    await chrome.debugger.attach(target, "1.3");
  } catch (err) {
    throw new Error(
      `Could not attach the debugger (is DevTools open?): ${err instanceof Error ? err.message : String(err)}`
    );
  }
  try {
    const metrics = await sendCmd(target, "Page.getLayoutMetrics");
    const content = metrics.cssContentSize ?? metrics.contentSize;
    if (!content) throw new Error("Could not determine the page size.");
    const clip = {
      x: 0,
      y: 0,
      width: Math.min(content.width, MAX_DIMENSION),
      height: Math.min(content.height, MAX_DIMENSION),
      scale: 1
    };
    const result = await sendCmd(target, "Page.captureScreenshot", {
      format: "png",
      captureBeyondViewport: true,
      clip
    });
    return `data:image/png;base64,${result.data}`;
  } finally {
    await chrome.debugger.detach(target).catch(() => void 0);
  }
}
function sendCmd(target, method, params) {
  return new Promise((resolve, reject) => {
    chrome.debugger.sendCommand(target, method, params, (res) => {
      const err = chrome.runtime.lastError;
      if (err) reject(new Error(err.message));
      else resolve(res);
    });
  });
}
async function captureRegion(tabId, windowId) {
  const sel = await chrome.tabs.sendMessage(tabId, {
    type: "START_REGION_SELECT"
  });
  if (sel.cancelled) throw new Error("Selection cancelled.");
  const full = await captureViewport(windowId);
  return cropDataUrl(full, sel.rect, sel.devicePixelRatio);
}
async function cropDataUrl(dataUrl, rect, dpr) {
  const bitmap = await createImageBitmap(await dataUrlToBlob(dataUrl));
  const sx = Math.round(rect.x * dpr);
  const sy = Math.round(rect.y * dpr);
  const sw = Math.max(1, Math.round(rect.w * dpr));
  const sh = Math.max(1, Math.round(rect.h * dpr));
  const canvas = new OffscreenCanvas(sw, sh);
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("Canvas context unavailable.");
  ctx.drawImage(bitmap, sx, sy, sw, sh, 0, 0, sw, sh);
  bitmap.close();
  return blobToDataUrl(await canvas.convertToBlob({ type: "image/png" }));
}
async function getPageInfo(tabId) {
  const page = await getPageMeta(tabId);
  let diagnostics = { consoleErrors: [], failedRequests: [] };
  try {
    const res = await chrome.tabs.sendMessage(tabId, { type: "GET_PAGE_INFO" });
    if (res?.diagnostics) diagnostics = res.diagnostics;
  } catch {
  }
  return { page, diagnostics };
}
async function getPageMeta(tabId) {
  try {
    const [{ result }] = await chrome.scripting.executeScript({ target: { tabId }, func: collectPageInfo });
    if (result) return result;
  } catch {
  }
  const tab = await chrome.tabs.get(tabId);
  return {
    url: tab.url ?? "",
    title: tab.title ?? "",
    userAgent: "",
    viewport: { width: 0, height: 0 },
    devicePixelRatio: 1,
    scroll: { x: 0, y: 0 },
    browser: {
      name: "",
      version: "",
      platform: "",
      language: "",
      screen: { width: 0, height: 0 },
      mobile: false,
      touchPoints: 0
    }
  };
}
function redactDiagnostics(d) {
  return {
    consoleErrors: d.consoleErrors,
    failedRequests: d.failedRequests.map((r) => ({ ...r, url: redactUrl(r.url) }))
  };
}
async function imageSize(dataUrl) {
  const bitmap = await createImageBitmap(await dataUrlToBlob(dataUrl));
  const size = { width: bitmap.width, height: bitmap.height };
  bitmap.close();
  return size;
}
async function dataUrlToBlob(dataUrl) {
  return (await fetch(dataUrl)).blob();
}
function blobToDataUrl(blob) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = () => reject(reader.error);
    reader.readAsDataURL(blob);
  });
}
