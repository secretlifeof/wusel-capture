(() => {
  // src/content/collector.ts
  (() => {
    const MAX = 100;
    const consoleErrors = [];
    const failedRequests = [];
    const now = () => (/* @__PURE__ */ new Date()).toISOString();
    const push = (arr, item) => {
      arr.push(item);
      if (arr.length > MAX) arr.shift();
    };
    const post = (msg) => window.postMessage({ __ckCollector: true, ...msg }, "*");
    const truncate = (s, n) => s.length > n ? `${s.slice(0, n)}\u2026` : s;
    const stringify = (a) => {
      if (typeof a === "string") return a;
      if (a instanceof Error) return a.stack || a.message;
      try {
        return JSON.stringify(a);
      } catch {
        return String(a);
      }
    };
    const recordConsole = (level, args, source) => {
      const entry = {
        level,
        message: truncate(args.map(stringify).join(" "), 2e3),
        source,
        timestamp: now()
      };
      push(consoleErrors, entry);
      post({ kind: "entry", entryType: "console", payload: entry });
    };
    const recordRequest = (r) => {
      const entry = { ...r, timestamp: now() };
      push(failedRequests, entry);
      post({ kind: "entry", entryType: "request", payload: entry });
    };
    try {
      const origError = console.error.bind(console);
      const origWarn = console.warn.bind(console);
      console.error = (...args) => {
        try {
          recordConsole("error", args);
        } catch {
        }
        return origError(...args);
      };
      console.warn = (...args) => {
        try {
          recordConsole("warn", args);
        } catch {
        }
        return origWarn(...args);
      };
    } catch {
    }
    window.addEventListener("error", (e) => {
      const source = e.filename ? `${e.filename}:${e.lineno}:${e.colno}` : void 0;
      recordConsole("error", [e.message || "Uncaught error"], source);
    });
    window.addEventListener("unhandledrejection", (e) => {
      const reason = e.reason;
      const message = typeof reason === "object" && reason?.message ? reason.message : String(reason);
      recordConsole("error", [`Unhandled rejection: ${message}`]);
    });
    try {
      const origFetch = window.fetch;
      if (typeof origFetch === "function") {
        window.fetch = async function(...args) {
          const [input, init] = args;
          const url = typeof input === "string" ? input : input instanceof URL ? input.href : input?.url ?? String(input);
          const method = init?.method ?? input?.method ?? "GET";
          try {
            const res = await origFetch.apply(this, args);
            if (!res.ok) {
              recordRequest({ url, method, status: res.status, statusText: res.statusText, type: "fetch" });
            }
            return res;
          } catch (err) {
            const msg = err instanceof Error ? err.message : "Network error";
            recordRequest({ url, method, status: 0, statusText: msg, type: "fetch" });
            throw err;
          }
        };
      }
    } catch {
    }
    try {
      const Xhr = window.XMLHttpRequest;
      if (Xhr) {
        const open = Xhr.prototype.open;
        const send = Xhr.prototype.send;
        Xhr.prototype.open = function(method, url, ...rest) {
          this.__ck = { method, url: String(url) };
          return open.apply(this, [method, url, ...rest]);
        };
        Xhr.prototype.send = function(...a) {
          this.addEventListener("loadend", () => {
            if (this.status === 0 || this.status >= 400) {
              const meta = this.__ck ?? { method: "GET", url: "" };
              recordRequest({
                url: meta.url,
                method: meta.method,
                status: this.status,
                statusText: this.statusText || (this.status === 0 ? "Network error" : ""),
                type: "xhr"
              });
            }
          });
          return send.apply(this, a);
        };
      }
    } catch {
    }
    window.addEventListener("message", (e) => {
      if (e.source !== window) return;
      const data = e.data;
      if (data?.__ckBridge && data.kind === "flush") {
        post({ kind: "snapshot", console: consoleErrors.slice(), requests: failedRequests.slice() });
      }
    });
  })();
})();
