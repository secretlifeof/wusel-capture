(() => {
  // src/lib/page-info.ts
  function collectPageInfo() {
    const ua = navigator.userAgent;
    const nav = navigator;
    const grab = (re) => {
      const m = ua.match(re);
      return m ? m[1] : "";
    };
    let name = "Unknown";
    let version = "";
    if (/Edg\//.test(ua)) {
      name = "Edge";
      version = grab(/Edg\/([\d.]+)/);
    } else if (/OPR\//.test(ua) || /Opera/.test(ua)) {
      name = "Opera";
      version = grab(/(?:OPR|Opera)\/([\d.]+)/);
    } else if (/Firefox\//.test(ua)) {
      name = "Firefox";
      version = grab(/Firefox\/([\d.]+)/);
    } else if (/Chrome\//.test(ua)) {
      name = nav.brave ? "Brave" : "Chrome";
      version = grab(/Chrome\/([\d.]+)/);
    } else if (/Safari\//.test(ua) && /Version\//.test(ua)) {
      name = "Safari";
      version = grab(/Version\/([\d.]+)/);
    }
    let platform = nav.userAgentData?.platform || navigator.platform || "";
    if (/Windows NT/.test(ua)) platform = "Windows";
    else if (/Mac OS X/.test(ua)) platform = "macOS";
    else if (/Android/.test(ua)) platform = "Android";
    else if (/(iPhone|iPad|iPod)/.test(ua)) platform = "iOS";
    else if (!platform && /Linux/.test(ua)) platform = "Linux";
    const mobile = typeof nav.userAgentData?.mobile === "boolean" ? nav.userAgentData.mobile : /Mobile|Android|iPhone|iPad|iPod/.test(ua);
    return {
      url: location.href,
      title: document.title,
      userAgent: ua,
      viewport: { width: window.innerWidth, height: window.innerHeight },
      devicePixelRatio: window.devicePixelRatio,
      scroll: { x: Math.round(window.scrollX), y: Math.round(window.scrollY) },
      browser: {
        name,
        version,
        platform,
        language: navigator.language || "",
        screen: { width: window.screen?.width ?? 0, height: window.screen?.height ?? 0 },
        mobile,
        touchPoints: navigator.maxTouchPoints || 0
      }
    };
  }

  // src/content/bridge.ts
  var MAX = 100;
  var consoleErrors = [];
  var failedRequests = [];
  var flushResolve = null;
  function replace(target, next) {
    target.length = 0;
    for (const item of next.slice(-MAX)) target.push(item);
  }
  function pushCapped(target, item) {
    target.push(item);
    if (target.length > MAX) target.shift();
  }
  window.addEventListener("message", (e) => {
    if (e.source !== window) return;
    const d = e.data;
    if (!d?.__ckCollector) return;
    if (d.kind === "entry") {
      if (d.entryType === "console") pushCapped(consoleErrors, d.payload);
      else if (d.entryType === "request") pushCapped(failedRequests, d.payload);
    } else if (d.kind === "snapshot") {
      replace(consoleErrors, d.console ?? []);
      replace(failedRequests, d.requests ?? []);
      flushResolve?.();
      flushResolve = null;
    }
  });
  function requestFlush() {
    return new Promise((resolve) => {
      flushResolve = resolve;
      window.postMessage({ __ckBridge: true, kind: "flush" }, "*");
      setTimeout(() => {
        flushResolve = null;
        resolve();
      }, 80);
    });
  }
  async function handleGetPageInfo() {
    await requestFlush();
    return {
      page: collectPageInfo(),
      diagnostics: { consoleErrors: consoleErrors.slice(), failedRequests: failedRequests.slice() }
    };
  }
  function startRegionSelect() {
    return new Promise((resolve) => {
      const overlay = document.createElement("div");
      Object.assign(overlay.style, {
        position: "fixed",
        inset: "0",
        zIndex: "2147483647",
        cursor: "crosshair",
        background: "transparent"
      });
      const box = document.createElement("div");
      Object.assign(box.style, {
        position: "fixed",
        display: "none",
        border: "2px solid #fff",
        boxShadow: "0 0 0 9999px rgba(15,15,15,0.4)",
        pointerEvents: "none"
      });
      const hint = document.createElement("div");
      hint.textContent = "Drag to select \xB7 Esc to cancel";
      Object.assign(hint.style, {
        position: "fixed",
        top: "12px",
        left: "50%",
        transform: "translateX(-50%)",
        zIndex: "2147483647",
        background: "rgba(0,0,0,0.78)",
        color: "#fff",
        font: "500 13px/1.4 ui-sans-serif, system-ui, sans-serif",
        padding: "6px 14px",
        borderRadius: "9999px",
        pointerEvents: "none"
      });
      overlay.appendChild(box);
      const host = document.documentElement;
      host.appendChild(overlay);
      host.appendChild(hint);
      let dragging = false;
      let startX = 0;
      let startY = 0;
      let rect = { x: 0, y: 0, w: 0, h: 0 };
      const cleanup = () => {
        overlay.remove();
        hint.remove();
        window.removeEventListener("keydown", onKey, true);
      };
      const finish = (res) => {
        cleanup();
        requestAnimationFrame(() => requestAnimationFrame(() => resolve(res)));
      };
      const update = (e) => {
        const x = Math.min(startX, e.clientX);
        const y = Math.min(startY, e.clientY);
        const w = Math.abs(e.clientX - startX);
        const h = Math.abs(e.clientY - startY);
        rect = { x, y, w, h };
        Object.assign(box.style, { left: `${x}px`, top: `${y}px`, width: `${w}px`, height: `${h}px` });
      };
      const onKey = (e) => {
        if (e.key === "Escape") {
          e.preventDefault();
          finish({ cancelled: true });
        }
      };
      overlay.addEventListener("mousedown", (e) => {
        dragging = true;
        startX = e.clientX;
        startY = e.clientY;
        box.style.display = "block";
        update(e);
      });
      overlay.addEventListener("mousemove", (e) => {
        if (dragging) update(e);
      });
      overlay.addEventListener("mouseup", (e) => {
        if (!dragging) return;
        dragging = false;
        update(e);
        if (rect.w < 4 || rect.h < 4) finish({ cancelled: true });
        else finish({ cancelled: false, rect, devicePixelRatio: window.devicePixelRatio });
      });
      window.addEventListener("keydown", onKey, true);
    });
  }
  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    const type = message?.type;
    if (type === "GET_PAGE_INFO") {
      handleGetPageInfo().then(sendResponse);
      return true;
    }
    if (type === "START_REGION_SELECT") {
      startRegionSelect().then(sendResponse);
      return true;
    }
    return false;
  });
})();
